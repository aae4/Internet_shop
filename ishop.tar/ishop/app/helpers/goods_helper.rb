module GoodsHelper
end
