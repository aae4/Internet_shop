class PremissionController < ApplicationController
end
