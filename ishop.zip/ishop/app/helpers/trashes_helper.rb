module TrashesHelper
end
