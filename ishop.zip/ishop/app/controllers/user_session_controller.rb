class UserSessionController < ApplicationController
end
