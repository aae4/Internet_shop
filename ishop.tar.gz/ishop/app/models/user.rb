class User < ActiveRecord::Base
	has_many :permissions
  	has_many :roles, :through => :permissions
	validates_presence_of :login
	validates_uniqueness_of :login
	
	attr_accessor :password_confirmation
	validates_confirmation_of :password
		

	def self.auth(login, password)
		user=self.find_by_login(login)
		user
	end

	def has_role?(name)
    		self.roles.find_by_login(login) ? true : false
  	end
end
