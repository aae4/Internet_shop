class UserSession < ActiveRecord::Base
end
